var app = require('http').createServer(handler)
var io = require('socket.io')(app);
var fs = require('fs');
//require module
var Scanner = require("bluetooth-scanner");
 var a='';
// define input
var device = "hci0";
//var mac=1;
app.listen(80);

function handler (req, res) {
  fs.readFile(__dirname + '/index.html',
  function (err, data) {
    if (err) {
      res.writeHead(500);
      return res.end('Error loading index.html');
    }

    res.writeHead(200);
    res.end(data);
  });
}

 io.on('connection', function (socket) {

function main()
{  
  a='';
  // Scan for devices
	var bleScanner = new Scanner(device);
       
	bleScanner.on("device",function(mac, name) {
  	 a+='#'+name+' with address '+ mac+'#'+'\r\n';
	  console.log('Found device: ', name, ' with MAC: ', mac);
        socket.emit('news',a);
	 
 	});
 
	bleScanner.on("done", function(msg){
		//console.log(msg);
		main();
	});

 
}
main(); 
});
  
   








