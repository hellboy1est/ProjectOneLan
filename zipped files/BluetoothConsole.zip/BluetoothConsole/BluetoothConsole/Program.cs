﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using InTheHand;
using InTheHand.Net.Bluetooth;
using InTheHand.Net.Ports;
using InTheHand.Net.Sockets;

using MySql;
using MySql.Data.MySqlClient;
using System.Diagnostics;

namespace BluetoothConsole
{
    class Program
    {

       public static SQLClient sqlClient = new SQLClient("localhost", "getaddress", "root", "");

       public static List<Device> userDevices = new List<Device>();
        
        static void Main(string[] args)
        {
            //Runs Method
            InitDeviceList();
          
            BluetoothClient bc = new BluetoothClient();
            BluetoothDeviceInfo[] devices = bc.DiscoverDevices();          

            
            string a = "dadasd";
            string b = "";
            int number = 0;

            for (int i = 0; i < devices.Length; i++)
            {
                a = number + ") " + devices[i].DeviceName + "/" + "Address: " + devices[i].DeviceAddress + "\r\n";
                Console.WriteLine(a);


                for (int j = 0; j < userDevices.Count; j++)
                {
                    if (devices[i].DeviceAddress.ToString() == userDevices[j].Address)
                    {
                        //convert list items to string
                        string username = (userDevices[j].UserName.ToString().ToUpper());

                        //adds '' to string,so sql can accept as a char
                        string knownuser = "'" + username.Replace(",", "','") + "'";

                      //  listBox1.Items.Add(userDevices[j].UserName);

                        sqlClient.Insert("tblknown", "name", knownuser);
                        sqlClient.Update("tblknown", "counting =counting+1", "id=1");
                    }

                }

                number++;
             
            }
            Console.ReadLine();
            
        }

        //Adds Devices manually to userDevices instance
        static void InitDeviceList()
        {
            userDevices.Add(new Device("Rahul", "08FC88541032"));
            userDevices.Add(new Device("John", "3C915712CAC1"));
            userDevices.Add(new Device("Chris", "F06BCA92E623"));
            userDevices.Add(new Device("Catherine", "00F46FACBD86"));
            userDevices.Add(new Device("Tanuj", "D40B1AFC74D6"));
            userDevices.Add(new Device("Paul", "AE3C4666286A"));
            userDevices.Add(new Device("Elvis", "2CD05A133FD2"));
        }

    }
}
