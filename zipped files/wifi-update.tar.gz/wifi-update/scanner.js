// scanner.js

var wifiscanner = require('node-wifiscanner/lib/wifiscanner.js');

wifiscanner.scan(function(err, data){
    if (err) {
        console.log("Error : " + err);
        return;
    }

    console.log(data);
});
