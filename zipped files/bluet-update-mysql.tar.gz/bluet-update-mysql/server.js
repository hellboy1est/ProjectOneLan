 

var app = require('http').createServer(handler)
var io = require('socket.io')(app);
var fs = require('fs');
 
//var Scanner = require("bluetooth-scanner");
 
 
// define input
var devices = "hci0";
//var mac=1;
app.listen(80);


function handler (req, res) {
  fs.readFile(__dirname + '/sql.html',
  function (err, data) {
    if (err) {
      res.writeHead(500);
      return res.end('Error loading index.html');
    }

    res.writeHead(200);
    res.end(data);
  });
}

io.on('connection', function (socket) {
  
	socket.on('add-user', function(rows) {
       // devices.push({'address': device.mac,'name': device.name});
       io.emit('data', rows); // send device to browsers
       console.log('data',rows);
   });
  socket.on('add-device', function(mac,name) {
       // devices.push({'address': device.mac,'name': device.name});
       io.emit('news', mac, name); // send device to browsers
       console.log('news', mac, name);
   });

  socket.on('get-devices', function(payload){ });


});
