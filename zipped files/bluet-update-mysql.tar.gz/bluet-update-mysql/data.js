 
var mysql   = require('mysql');
var connection = mysql.createConnection({
  host     : "sql3.freemysqlhosting.net",
 
  user     : "sql394040",
  password : "zT2*mS8*",
  database : "sql394040"
});

function main(){
connection.connect();
var a
connection.query("SELECT * FROM data", function(err, rows, fields) {

  a=rows;
  if (!err){
    console.log('The solution is: ', rows);
		 
}
  else{
    console.log('Error while performing Query.',err);}
});
	
connection.end();
  return a;
 console.log(a);
}
main();
