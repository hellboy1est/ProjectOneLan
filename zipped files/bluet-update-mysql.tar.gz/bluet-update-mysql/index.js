//var app = require('http').createServer(handler)
//var io = require('socket.io')(app);
//var fs = require('fs');
//require module
//var Scanner = require("bluetooth-scanner");
// var a='';
 
// define input
//var device = "hci0";
//var mac=1;
//app.listen(80);
 
var mysql   = require('mysql');
var connection = mysql.createConnection({
  host     : "sql3.freemysqlhosting.net",
 
  user     : "sql394040",
  password : "zT2*mS8*",
  database : "sql394040"
});
var port = 80,
    devices = "hci0",
    socket = require('socket.io-client')('http://localhost:'+port);
    Scanner = require("bluetooth-scanner");
  

function main()
{   
	 	var a;
		connection.query("SELECT * FROM data", function(err, rows, fields) {

			a=rows;
			if (!err){
				console.log('The solution is: ', rows);
				 socket.emit('add-user', rows);
		}
			else{
				console.log('Error while performing Query.',err);}
		});
	 
		
	/**	var queryString="SELECT t.ID, u.fName,u.lName,u.bluetooth,u.image, d.day, p.period FROM StaffTimeTable t JOIN data u on u.id = t.userID  JOIN day_of_week d on d.ID =t.dayID  JOIN periods p on p.ID = t.periodID ORDER BY t.id";
		 
		 console.log(queryString);
		
		connection.query(queryString, function(err, rows, fields) {

			a=rows;
			if (!err){
				console.log('The solution is: ', rows);
				 socket.emit('add-user', rows);
		}
			else{
				console.log('Error while performing Query.',err);}
		});
		**/
		var bleScanner = new Scanner(devices);
    bleScanner.on("device",function(mac, name) {
     	console.log('Found device: ', name, ' with MAC: ', mac);
    	//var message = {'address': mac, 'name': name}; // prepare message
	  socket.emit('add-device', mac, name);
    	//sendMessage('add-device', mac,name); // actually send message to 		server
        //console.log("Sent new device", message);
	
    }); 
		
    bleScanner.on("done", function(msg){
      console.log(msg);
			
      main();
    }); 
 
}  

main();
  





