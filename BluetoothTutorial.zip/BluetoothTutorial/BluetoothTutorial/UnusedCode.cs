﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BluetoothTutorial
{
    class UnusedCode
    {

        //if (b == "08FC88541032")
        //{
        //    //only last address gets stored? needs all to check
        //    label3.Text += "Rahul";
        //  //  MessageBox.Show("Hello Rahul ");
        //}
        //else if (b == "3C915712CAC1")
        //{
        //    //only last address gets stored? needs all to check
        //    label3.Text += "John";
        //  //  MessageBox.Show("Hello John ");
        //}
        //else if(b=="E899C4127E5F")
        //{
        //    label3.Text += "Elvis";
        //   // MessageBox.Show("Hello Elvis ");
        //} 

        //SelectBluetoothDeviceDialog sbdd = new SelectBluetoothDeviceDialog();         
        //sbdd.ShowUnknown = true;
        //sbdd.ShowRemembered = true;
        //sbdd.ShowAuthenticated = true;


        //if (sbdd.ShowDialog() == DialogResult.OK)
        //{
        //    tbOutput.AppendText("Device Name: "+ sbdd.SelectedDevice.DeviceName+"\r\n");
        //    tbOutput.AppendText("Device Address: " + sbdd.SelectedDevice.DeviceAddress.ToString() + "\r\n");
        ////////////    tbOutput.AppendText("Remembered: " + sbdd.ShowRemembered.ToString() + "\r\n");
        //    tbOutput.AppendText("Last Used: " + sbdd.SelectedDevice.LastUsed.ToString()+ "\r\n");
        //    tbOutput.AppendText("Last Seen: " + sbdd.SelectedDevice.LastSeen.ToString()+"\r\n");
        //    tbOutput.AppendText("Connected: " + sbdd.SelectedDevice.Connected.ToString());
        //}


        //  private void Form1_Load(object sender, EventArgs e)
        // {
            //        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;

        //  webBrowser1.DocumentText =
        //"<html><head><meta http-equiv='refresh' content='0; url=https://www.op.ac.nz/hub/' /> </head><body>" +

        //     "</body></html>";
           


        // }
       
         //  public void InitDeviceList()
        //  {
            //userDevices.Add(new Device("Rahul", "08FC88541032"));
            //userDevices.Add(new Device("John", "3C915712CAC1"));
            //userDevices.Add(new Device("Chris", "F06BCA92E623"));
            //userDevices.Add(new Device("Catherine", "00F46FACBD86"));
            //userDevices.Add(new Device("Tanuj", "D40B1AFC74D6"));
            //userDevices.Add(new Device("Paul", "AE3C4666286A"));
            //userDevices.Add(new Device("Elvis", "2CD05A133FD2"));
            //userDevices.Add(new Device("Nappa", "4480EB7E4CB6"));


            //    private void WelcomeMessage()
       //   {

             // if (listBox1.Items.Count > 0)
             // {
                // It contains items
                
              //    if (listBox1.Items.Contains("Rahul"))
                //  {                     
                //      webBrowser1.DocumentText =
                //            "<html><head><meta http-equiv='refresh' content='0; url=http://webdev.ict.op.ac.nz/kakkr1/web3Final/' /> </head><body>" +
                 //           "</body></html>";

               //   }
                //else if (listBox1.Items.Contains("John"))                 
                //{
                //    webBrowser1.DocumentText =
                //             "<html><body>" +
                //             "<h1>Welcome John</h1>" +
                //             "</body></html>";
                      
                //}
                 // else if (listBox1.Items.Contains("Tanuj"))
                //  {
                 //     webBrowser1.DocumentText =
                   //            "<html><body>" +
                  //             "<h1>Welcome Tanuj</h1>" +
                    //           "</body></html>";

                //  }

        

        
                 // else
                 // {
                    // It doesn't
          //
                  //    webBrowser1.DocumentText =
                   //               "<html><head><meta http-equiv='refresh' content='0; url=https://www.op.ac.nz/hub/' /></head><body>" +
          //
                   //               "</body></html>";
                 // }

           
             // else
             // {
                // It doesn't

              //    webBrowser1.DocumentText =
                //              "<html><head><meta http-equiv='refresh' content='0; url=https://www.op.ac.nz/hub/' /></head><body>" +
      //
                   //           "</body></html>";
            //  }
            

         // }
        //private void SendData()
        //{
        //    System.Net.WebClient wc = new System.Net.WebClient();
        //    string webData = wc.DownloadString("http://kate.ict.op.ac.nz/~kakkr1/Assignment2/add.html");
            
        //    MessageBox.Show(webData);

        //}

    //  }
    }
}
